# Resume → Careers Page Matcher (Streamlit)

Deploy in minutes on **Streamlit Community Cloud** or **Hugging Face Spaces**.

## Quick start (local)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy: Streamlit Community Cloud
1. Create a new GitHub repo, add these files.
2. Go to https://share.streamlit.io -> **Deploy an app**.
3. Select your repo, branch, and set **app file** = `app.py`.
4. Advanced: Python 3.10+; no secrets required.

## Deploy: Hugging Face Spaces
1. New Space → **Streamlit**.
2. Upload `app.py` and `requirements.txt`.
3. Save; the Space will build and run.

Notes:
- Some ATS pages require JS; this app uses HTML fetching only.
- Use the sidebar selector override for tricky pages.
