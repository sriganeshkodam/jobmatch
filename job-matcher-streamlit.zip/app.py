# =============================================================================
# File: app.py
# =============================================================================
import io
import re
import csv
import time
import json
import string
import typing as t
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

import streamlit as st

# Optional imports guarded for environments without extras
try:
    from PyPDF2 import PdfReader  # pure-Python; avoids system deps
except Exception:  # pragma: no cover
    PdfReader = None  # type: ignore

try:
    import docx  # python-docx
except Exception:  # pragma: no cover
    docx = None  # type: ignore


# ---------------------------- Constants --------------------------------------

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
REQUEST_TIMEOUT = 15
SLEEP_BETWEEN_REQUESTS = 0.3  # Why: avoid hammering fragile job boards

STOPWORDS = {
    # compact, pragmatic set; not exhaustive; favors tech terms to remain
    "a","an","and","the","of","for","to","in","on","with","is","are","as","at",
    "by","be","or","from","that","this","it","its","into","your","you","we",
    "us","our","they","their","them","will","can","may","if","not","but","about",
    "what","when","where","which","who","how","than","then","over","per","via",
    "using","use","used","within","without","across","each","any","all","more",
    "most","least","such","including","include","includes","i","me","my","mine",
    "he","she","him","her","his","hers","there","here","up","down","out","so",
    "these","those","also","etc","eg","ie","vs","&","-","—"
}

JOB_LINK_HINTS = ("job", "jobs", "career", "careers", "opening", "openings", "position", "positions", "opportunity", "opportunities", "vacancy", "vacancies", "requisition")

ATS_MARKERS = {
    "greenhouse": ("boards.greenhouse.io", "greenhouse.io"),
    "lever": ("jobs.lever.co", "lever.co"),
    "workday": ("myworkdayjobs.com", "wd5.myworkday.com"),
    "ashby": ("jobs.ashbyhq.com", "ashbyhq.com"),
    "smartrecruiters": ("smartrecruiters.com",),
}

HEADERS = {"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"}


# ---------------------------- Utilities --------------------------------------

def fetch(url: str) -> t.Optional[str]:
    """HTTP GET with UA and timeout; returns text or None."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        if r.status_code == 200 and r.text:
            return r.text
    except requests.RequestException:
        return None
    return None


def is_same_domain(parent_url: str, child_url: str) -> bool:
    """Check if child_url is same registrable domain as parent_url."""
    try:
        p = urlparse(parent_url)
        c = urlparse(child_url)
        return p.hostname.split(".")[-2:] == (c.hostname or "").split(".")[-2:]
    except Exception:
        return False


def absolutize(base: str, link: str) -> str:
    """Join relative links safely."""
    return urljoin(base, link)


def clean_text(s: str) -> str:
    """Normalize whitespace."""
    return re.sub(r"\s+", " ", s).strip()


def extract_main_text(html: str) -> str:
    """
    Heuristic: pick the largest meaningful text section.
    Why: job pages differ wildly; this avoids brittle selectors.
    """
    soup = BeautifulSoup(html, "html.parser")

    # Remove script/style/nav/footer
    for tag in soup(["script", "style", "noscript", "header", "footer", "svg"]):
        tag.decompose()

    candidates = soup.find_all(["article", "section", "div"])
    best = ""
    best_len = 0
    for c in candidates:
        txt = clean_text(c.get_text(" "))
        # Skip containers with too many links (likely nav/menus)
        if txt and len(c.find_all("a")) < 40:
            L = len(txt)
            if L > best_len:
                best_len = L
                best = txt
    if best:
        return best
    # Fallback to body text
    body = soup.get_text(" ")
    return clean_text(body)


# ---------------------------- Resume parsing ---------------------------------

def read_pdf(file_bytes: bytes) -> str:
    if PdfReader is None:
        return ""
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
        texts = []
        for page in reader.pages:
            try:
                texts.append(page.extract_text() or "")
            except Exception:
                continue
        return "\n".join(texts)
    except Exception:
        return ""


def read_docx(file_bytes: bytes) -> str:
    if docx is None:
        return ""
    try:
        buf = io.BytesIO(file_bytes)
        document = docx.Document(buf)
        return "\n".join(p.text for p in document.paragraphs)
    except Exception:
        return ""


def read_txt(file_bytes: bytes) -> str:
    try:
        return file_bytes.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def extract_resume_text(uploaded_file) -> str:
    suffix = (uploaded_file.name or "").lower()
    data = uploaded_file.read()
    if suffix.endswith(".pdf"):
        txt = read_pdf(data)
    elif suffix.endswith(".docx"):
        txt = read_docx(data)
    else:
        txt = read_txt(data)
    return clean_text(txt)


# ---------------------------- Tokenization & keywords ------------------------

TOKEN_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9\-\+#\.]{1,50}")

def tokenize(text: str) -> t.List[str]:
    text = text.lower()
    tokens = TOKEN_PATTERN.findall(text)
    return tokens

def keywords_from_text(text: str, min_len: int = 2) -> t.Set[str]:
    toks = tokenize(text)
    kws = {t for t in toks if (t not in STOPWORDS and len(t) >= min_len)}
    return kws

def freq_map(tokens: t.Iterable[str]) -> t.Dict[str, int]:
    d: t.Dict[str, int] = {}
    for tkn in tokens:
        d[tkn] = d.get(tkn, 0) + 1
    return d


# ---------------------------- Job board detection ----------------------------

def detect_ats(url: str, html: str) -> str:
    host = urlparse(url).hostname or ""
    for ats, hosts in ATS_MARKERS.items():
        if any(h in host for h in hosts):
            return ats

    # Secondary hints in HTML
    lower = html.lower()
    if "greenhouse" in lower:
        return "greenhouse"
    if "lever.co" in lower or "lever-jobs" in lower:
        return "lever"
    if "myworkdayjobs" in lower or "workday" in lower:
        return "workday"
    if "ashbyhq" in lower:
        return "ashby"
    if "smartrecruiters" in lower:
        return "smartrecruiters"
    return "generic"


# ---------------------------- Job extraction per ATS -------------------------

def extract_jobs_generic(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    seen = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        text = clean_text(a.get_text(" "))
        if not text:
            continue
        if not any(h in href.lower() or h in text.lower() for h in JOB_LINK_HINTS):
            continue
        link = absolutize(base_url, href)
        if link in seen:
            continue
        seen.add(link)
        jobs.append({
            "title": text[:200],
            "location": "",
            "link": link
        })
    return jobs

def extract_jobs_greenhouse(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    for li in soup.select("div.opening a, a[href*='boards.greenhouse.io']"):
        link = absolutize(base_url, li.get("href", ""))
        title = clean_text(li.get_text(" "))
        loc = ""
        # Try to find sibling/location
        parent = li.find_parent()
        if parent:
            loc_el = parent.find(class_=re.compile("location", re.I))
            if loc_el:
                loc = clean_text(loc_el.get_text(" "))
        jobs.append({"title": title, "location": loc, "link": link})
    return jobs

def extract_jobs_lever(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    for row in soup.select("div.posting, a.posting-title, a[href*='jobs.lever.co']"):
        a = row if row.name == "a" else row.select_one("a[href]")
        if not a:
            continue
        link = absolutize(base_url, a["href"])
        title_el = row.select_one(".posting-title h5, h3, h2") if row.name != "a" else a
        title = clean_text(title_el.get_text(" ")) if title_el else clean_text(a.get_text(" "))
        loc_el = row.select_one(".posting-categories .location, .sort-by-location, .location")
        loc = clean_text(loc_el.get_text(" ")) if loc_el else ""
        jobs.append({"title": title, "location": loc, "link": link})
    return jobs

def extract_jobs_workday(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    # Workday often renders client-side; fallback to all anchors containing job requisitions
    for a in soup.select("a[href]"):
        href = a.get("href", "")
        if "myworkdayjobs" in href or re.search(r"job/|jobId=|jobPosting", href, re.I):
            link = absolutize(base_url, href)
            title = clean_text(a.get_text(" ")) or "Job"
            jobs.append({"title": title, "location": "", "link": link})
    # Try to parse embedded JSON (Workday has a large JSON in script tags)
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "{}")
            if isinstance(data, dict) and "title" in data and "hiringOrganization" in data:
                jobs.append({
                    "title": clean_text(str(data.get("title", ""))),
                    "location": clean_text(str(data.get("jobLocation", ""))),
                    "link": absolutize(base_url, str(data.get("url", base_url)))
                })
        except Exception:
            continue
    return jobs

def extract_jobs_ashby(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    for a in soup.select("a[href*='jobs.ashbyhq.com'], a[data-qa='job-card-title']"):
        link = absolutize(base_url, a.get("href", ""))
        title = clean_text(a.get_text(" "))
        loc = ""
        card = a.find_parent()
        if card:
            loc_el = card.find(string=re.compile("Remote|Hybrid|Office| - ", re.I))
            if loc_el:
                loc = clean_text(str(loc_el))
        jobs.append({"title": title, "location": loc, "link": link})
    return jobs

def extract_jobs_smartrecruiters(base_url: str, html: str) -> t.List[t.Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    for a in soup.select("a[href*='smartrecruiters.com/']"):
        link = absolutize(base_url, a.get("href", ""))
        title = clean_text(a.get_text(" "))
        loc = ""
        jobs.append({"title": title, "location": loc, "link": link})
    return jobs

ATS_EXTRACTORS = {
    "generic": extract_jobs_generic,
    "greenhouse": extract_jobs_greenhouse,
    "lever": extract_jobs_lever,
    "workday": extract_jobs_workday,
    "ashby": extract_jobs_ashby,
    "smartrecruiters": extract_jobs_smartrecruiters,
}


# ---------------------------- Scoring ----------------------------------------

def jaccard(a: t.Set[str], b: t.Set[str]) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0

def score_job(resume_kw: t.Set[str], resume_freq: t.Dict[str, int], job_title: str, job_text: str) -> t.Tuple[float, t.List[str]]:
    job_tokens = tokenize(job_text)
    job_kw = {t for t in job_tokens if t not in STOPWORDS}
    overlap = resume_kw & job_kw
    jacc = jaccard(resume_kw, job_kw)

    # Frequency weight: emphasize recurring resume keywords
    freq_score = 0.0
    for k in overlap:
        # Why: prioritize skills heavily emphasized in resume
        freq_score += min(job_tokens.count(k) * (1 + 0.1 * resume_freq.get(k, 1)), 10)

    # Title boost if title contains strong tokens
    title_tokens = set(tokenize(job_title))
    title_overlap = len(resume_kw & title_tokens)
    title_boost = min(title_overlap * 2.5, 10)

    raw = (jacc * 60.0) + (min(freq_score, 30.0)) + title_boost
    score = max(0.0, min(100.0, raw))
    top_matches = sorted(overlap, key=lambda k: (-job_tokens.count(k), k))[:10]
    return score, top_matches


# ---------------------------- Streamlit UI -----------------------------------

st.set_page_config(page_title="Resume → Job Match Finder", page_icon="🔎", layout="wide")

st.title("🔎 Resume → Career Page Matcher")
st.caption("Upload a resume, paste a careers page URL, and get ranked job matches based on keyword overlap.")

with st.sidebar:
    st.header("Settings")
    max_jobs = st.slider("Max job links to evaluate", 5, 200, 60, step=5)
    same_domain_only = st.checkbox("Restrict to same domain links", value=True)
    selector_hint = st.text_input("Optional CSS selector for job links", placeholder="e.g., a.job-card, .opening a")
    top_k_show = st.slider("Show top N matches", 5, 100, 20, step=5)

col1, col2 = st.columns([0.55, 0.45], gap="large")

with col1:
    careers_url = st.text_input("Careers page URL", placeholder="https://company.com/careers")
    uploaded = st.file_uploader("Resume (PDF/DOCX/TXT)", type=["pdf", "docx", "txt"])

with col2:
    st.info("Tips:\n- Paste a listing page if possible.\n- You may add a CSS selector if detection struggles.\n- Supports Greenhouse, Lever, Workday, Ashby, SmartRecruiters, and generic pages.")

run = st.button("Find matches", type="primary", disabled=not (careers_url and uploaded))

results: t.List[t.Dict[str, t.Any]] = []

if run:
    if not careers_url or not uploaded:
        st.error("Provide both careers URL and a resume.")
        st.stop()

    with st.status("Processing…", expanded=True) as status:
        st.write("Reading resume…")
        resume_text = extract_resume_text(uploaded)
        if not resume_text:
            st.error("Could not extract text from resume. Try TXT or a text-based PDF/DOCX.")
            st.stop()

        resume_tokens = tokenize(resume_text)
        resume_kw = keywords_from_text(resume_text)
        resume_freq = freq_map(resume_tokens)

        st.write("Fetching careers page…")
        html = fetch(careers_url)
        if not html:
            st.error("Could not fetch the careers page.")
            st.stop()

        ats = detect_ats(careers_url, html)
        st.write(f"Detected source: **{ats.capitalize()}**")

        soup = BeautifulSoup(html, "html.parser")

        if selector_hint:
            st.write("Using custom selector override…")
            job_cards = []
            try:
                for a in soup.select(selector_hint):
                    if a.name != "a":
                        a = a.find("a", href=True) or a
                    href = a.get("href", "")
                    if not href:
                        continue
                    link = absolutize(careers_url, href)
                    if same_domain_only and not is_same_domain(careers_url, link):
                        continue
                    title = clean_text(a.get_text(" ")) or "Job"
                    job_cards.append({"title": title, "location": "", "link": link})
            except Exception:
                job_cards = []
        else:
            extractor = ATS_EXTRACTORS.get(ats, extract_jobs_generic)
            job_cards = extractor(careers_url, html)

            # Keep only likely job links
            pruned = []
            seen_links = set()
            for j in job_cards:
                link = j.get("link", "")
                if not link or link in seen_links:
                    continue
                seen_links.add(link)
                if same_domain_only and not is_same_domain(careers_url, link):
                    continue
                if not any(h in link.lower() for h in JOB_LINK_HINTS) and ats == "generic":
                    # Generic: ensure link looks like a job detail
                    continue
                pruned.append(j)
            job_cards = pruned

        if not job_cards:
            st.warning("No obvious job links found on this page. Try a different URL or add a CSS selector.")
            st.stop()

        st.write(f"Found {len(job_cards)} potential job links, evaluating up to {max_jobs}…")

        # Evaluate each job page
        evaluated = 0
        prog = st.progress(0)
        out_rows = []

        for idx, job in enumerate(job_cards[:max_jobs]):
            link = job["link"]
            time.sleep(SLEEP_BETWEEN_REQUESTS)
            job_html = fetch(link)
            if not job_html:
                continue
            job_text = extract_main_text(job_html)
            if not job_text:
                continue
            score, matched = score_job(resume_kw, resume_freq, job.get("title", ""), job_text)
            snippet = clean_text(job_text)[:600]
            out_rows.append({
                "title": job.get("title", ""),
                "location": job.get("location", ""),
                "score": round(score, 2),
                "link": link,
                "matched_keywords": ", ".join(matched),
                "snippet": snippet,
            })
            evaluated += 1
            prog.progress(min(100, int((evaluated / max(1, min(max_jobs, len(job_cards)))) * 100)))

        if not out_rows:
            st.warning("Could not evaluate any job details. The site may require JavaScript. Try a different page.")
            st.stop()

        # Sort by score desc
        out_rows.sort(key=lambda r: r["score"], reverse=True)
        status.update(label="Done", state="complete")

    st.subheader("Top Matches")
    st.dataframe(
        [{k: v for k, v in r.items() if k in ("title", "location", "score", "link", "matched_keywords")} for r in out_rows[:top_k_show]],
        use_container_width=True,
        height=400,
    )

    # Expanders with details
    for r in out_rows[:top_k_show]:
        with st.expander(f"{r['title']} — {r['location'] or 'Location N/A'}  •  Score: {r['score']}"):
            st.markdown(f"[Open job posting]({r['link']})")
            if r["matched_keywords"]:
                st.caption(f"Matched keywords: {r['matched_keywords']}")
            st.write(r["snippet"])

    # CSV download
    csv_buf = io.StringIO()
    writer = csv.DictWriter(csv_buf, fieldnames=list(out_rows[0].keys()))
    writer.writeheader()
    for row in out_rows:
        writer.writerow(row)
    st.download_button(
        label="Download CSV",
        data=csv_buf.getvalue().encode("utf-8"),
        file_name="job_matches.csv",
        mime="text/csv",
    )

    st.success(f"Evaluated {len(out_rows)} jobs. Showing top {min(top_k_show, len(out_rows))}.")
